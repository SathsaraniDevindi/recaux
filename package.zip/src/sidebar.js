import  React from 'react';
import SideNav, {  NavItem, NavIcon, NavText } from '@trendmicro/react-sidenav';
import '@trendmicro/react-sidenav/dist/react-sidenav.css';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Home from './pages/home';
import Email from './pages/email';
import Candidates from './pages/candidates';
import Recruitments from './pages/recruitments';
import Reports from './pages/reports';
import Users from './pages/users';
import './styling/images/girl.png';
import './App.css';




class Sidebar extends React.Component{
    render(){
        return(
            <Router>
    <Route render={({ location, history }) => (
        <React.Fragment>
            <SideNav className="sidenav"
                onSelect={(selected) => {
                    const to = '/' + selected;
                    if (location.pathname !== to) {
                        history.push(to);
                    }
                }}
            >
                <SideNav.Toggle /> 
                
                <br/><br/><br/>
                <img src={require('./styling/images/girl.png')} className="sidebar-image" alt="girl"/>
                <h5 align="center">Devindi Perera</h5>
                <SideNav.Nav defaultSelected="home">
                    <NavItem eventKey="home">
                        <NavIcon>
                            <i className="fa fa-fw fa-home" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Home
                        </NavText>
                    </NavItem>
                    
                    <NavItem eventKey="candidates">
                        <NavIcon>
                            <i className="can" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Candidates
                        </NavText>
                    </NavItem>

                    <NavItem eventKey="recruitments">
                        <NavIcon>
                            <i className="recruitments" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Recruitments
                        </NavText>
                    </NavItem>

                    <NavItem eventKey="email">
                        <NavIcon>
                            <i className="email" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Email
                        </NavText>
                    </NavItem>

                    <NavItem eventKey="reports">
                        <NavIcon>
                            <i className="reports" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Reports
                        </NavText>
                    </NavItem>

                    <NavItem eventKey="users">
                        <NavIcon>
                            <i className="users" style={{ fontSize: '1.75em' }} />
                        </NavIcon>
                        <NavText>
                            Users
                        </NavText>
                    </NavItem>
                    
                    <button className="button-logout">Log Out</button>
                
                </SideNav.Nav>
            </SideNav>
            <main>
               
                <Route exact path="/home" component={props => <Home />} />
                <Route path="/candidates" component={Candidates} />
                <Route path="/recruitments" component={Recruitments} />
                <Route path="/email" component={Email} />
                <Route path="/reports" component={Reports} />
                <Route path="/users" component={Users} />
                
            </main>
        </React.Fragment>
    )}
    />
</Router>
        );
    }
} 
export default Sidebar