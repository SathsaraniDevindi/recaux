import React from 'react';


function Home() {
  return (
    <div className="dv">
    <h1>Home</h1>
    </div>
  );
}

export default Home;
