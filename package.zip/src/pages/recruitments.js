import React from 'react';


function Recruitments() {
  return (
    <div className="dv">
    <h1>Recruitments
    
    </h1>
    </div>
  );
}

export default Recruitments;
