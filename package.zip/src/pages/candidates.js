import React from 'react';


function Candidates() {
  return (
    <div className="dv">
    <h1>Candidates</h1>
    </div>
  );
}

export default Candidates;
