import React from 'react';
import '../App.css';
import '../styling/images/candidates.jpg';
import '../styling/images/users.png';
import '../styling/images/recruitments.jpg';
import '../styling/images/bestUsers.jpg';
import '../styling/images/reject.jpg';
import '../styling/images/outsource.png';


function Reports() {
  return (
    <div className="container">
    <div className="App">
      <img src={require('../styling/images/recruitments.jpg')} className="image" alt="recruitments"/>
      <h3 className="bold">Recruitments</h3>
      <p className="para">Recruitment statistic report</p>
      <hr/>
      <button type="button" class="btn btn-light">Generate</button>
    </div>

    <div className="App">
     <img src={require('../styling/images/candidates.jpg')} className="image"  alt="candidates"/>
     <h3 className="bold">Candidates</h3>
     <p className="para">Candidate statistic report</p>
     <hr/>
     <button type="button" class="btn btn-light">Generate</button>
    </div>

    <div className="App">
     <img src={require('../styling/images/bestUsers.jpg')} className="image" alt="bestUsers"/>
     <h3 className="bold">Best Users</h3>
     <p className="para">User statistic report</p>
     <hr/>
     <button type="button" class="btn btn-light">Generate</button>
    </div>

    <div className="App">
     <img src={require('../styling/images/users.png')} className="image" alt="users"/>
     <h3 className="bold">Users</h3>
     <p className="para">User activity report</p>
     <hr/>
     <button type="button" class="btn btn-light">Generate</button>
    </div>

    <div className="App">
     <img src={require('../styling/images/reject.jpg')} className="image" alt="image"/>
     <h3 className="bold">Rejection Reasons</h3>
     <p className="para">Summary of rejection reasons</p>
     <hr/>
     <button type="button" class="btn btn-light">Generate</button>
    </div>

    <div className="App">
     <img src={require('../styling/images/outsource.png')} className="image" alt="outsource"/>
     <h3 className="bold">Outsource Projects</h3>
     <p className="para">User statistic report</p>
     <hr/>
     <button type="button" class="btn btn-light">Generate</button>
    </div>
    </div>
  );
}

export default Reports
