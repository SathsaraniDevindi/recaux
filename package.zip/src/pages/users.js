import React from 'react';


function Users() {
  return (
    <div className="dv">
    <h1>Users
    
    </h1>
    </div>
  );
}

export default Users;
