import React,{Component} from 'react';
import './App.css';
import Sidebar from './sidebar';

class App extends Component{
  render(){
    return(
      <div >
          <Sidebar/>
      </div>

      
    );
  }
}

export default App;






